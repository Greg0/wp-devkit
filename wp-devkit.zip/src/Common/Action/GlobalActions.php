<?php
namespace Plugin\DevKit\Common\Action;


interface GlobalActions
{
    public const PLUGINS_LOADED = 'plugins_loaded';
    public const CONTENT = 'the_content';
}
